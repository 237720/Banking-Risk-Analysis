import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Load CSV data
customers = pd.read_csv(r"C:\Users\shame\Downloads\data analytics project\New folder\customers.csv", encoding='utf8')
loans = pd.read_csv(r"C:\Users\shame\Downloads\data analytics project\New folder\loans.csv", encoding='utf8')
payments = pd.read_csv(r"C:\Users\shame\Downloads\data analytics project\New folder\payments.csv", encoding='utf8')
risk = pd.read_csv(r"C:\Users\shame\Downloads\data analytics project\New folder\risk_scores.csv", encoding='utf8')

# Merge datasets
loan_data = loans.merge(customers, on="customer_id", how="left")
loan_data = loan_data.merge(risk, on=["customer_id", "loan_id"], how="left")

# Feature Engineering
loan_data['debt_to_income'] = loan_data['loan_amount'] / loan_data['income']

# Risk Labeling
def label_risk(score):
    if pd.isnull(score):
        return 'Unknown'
    elif score < 0.4:
        return 'High'
    elif score < 0.7:
        return 'Medium'
    else:
        return 'Low'

loan_data['risk_level'] = loan_data['risk_score'].apply(label_risk)

# Save processed CSV
loan_data.to_csv("cleaned_loan_data.csv", index=False, encoding='utf8')

# ------------------------------
# Exploratory Data Analysis (EDA)
# ------------------------------

# Null value check
print("\nNull Values:")
print(loan_data.isnull().sum())

# Summary stats
print("\nSummary Statistics:")
print(loan_data.describe(include='all'))

# Risk level distribution
print("\nRisk Level Counts:")
print(loan_data['risk_level'].value_counts())

# Correlation heatmap
plt.figure(figsize=(10, 6))
sns.heatmap(loan_data.corr(numeric_only=True), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig("loan_data_heatmap.png")
plt.show()

# Save cleaned and processed CSV to Downloads folder
loan_data.to_csv(r"C:\Users\shame\Downloads\cleaned_loan_data.csv", index=False, encoding='utf8')
print("✅ cleaned_loan_data.csv has been saved successfully.")
